# HumanEval/23
# Loki Mode Multi-Agent Solution
# Attempts: 1
# Passed: True

def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)